## Installation project

`git clone https://github.com/LeCongThang/thefive.git`

`composer install`

`cp env.example .env`

setup db info and run:

`php artisan migrate`

`php artisan db:seed`


