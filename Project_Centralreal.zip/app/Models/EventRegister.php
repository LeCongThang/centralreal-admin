<?php
/**
 * Created by PhpStorm.
 * User: ThangLe
 * Date: 7/10/2018
 * Time: 10:55 PM
 */

namespace App\Models;


use Illuminate\Database\Eloquent\Model;

class EventRegister extends Model
{
    protected $table = 'event_register';

}