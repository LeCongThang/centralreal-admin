<?php
/**
 * Created by PhpStorm.
 * User: ThangLe
 * Date: 7/5/2018
 * Time: 3:59 PM
 */

namespace App\Http\Controllers\Backend\News;


use App\Http\Controllers\Controller;
use App\Models\News;
use Illuminate\Http\Request;
use File;
use Image;

class UpdateNewsController extends Controller
{
    public function Edit($id){
        try{
            $news=News::find($id);
            if($news){
                return view('backend.news.detail',[
                    'news'=>$news,
                ]);
            }else{
                return redirect('admin/error');
            }
        }catch (\Exception $e){
            return redirect('admin/error');
        }
    }
    public function Update($news_id,Request $request){
        try{
            if (empty($request->get('title_vi')))
                return redirect()->back()->with('error','Vui lòng không để trống tiêu đề tiếng việt')->withInput();
            if (empty($request->get('title_en')))
                return redirect()->back()->with('error','Vui lòng không để trống tiêu đề tiếng anh')->withInput();
            if (empty($request->get('description_vi')))
                return redirect()->back()->with('error','Vui lòng không để trống nội dung tiếng việt')->withInput();
            if (empty($request->get('description_en')))
                return redirect()->back()->with('error','Vui lòng không để trống nội dung tiếng anh')->withInput();
            $news=News::find($news_id);
            if($news){
                $image_old=$news->image;
                $flag=0;
                if ($request->hasFile('image')) {
                    $flag=1;
                    $image = $request->file('image');
                    $filename = 'news-' .time().'.'. $image->getClientOriginalExtension();
                    $destinationPath = public_path('images/news/'.$filename);
                    Image::make($image->getRealPath())->resize(800,600)->save($destinationPath);
                    $news->image = $filename;
                }
                $news->title_vi=$request->title_vi;
                $news->title_en=$request->title_en;
                $news->is_featured=$request->is_featured ? $request->is_featured : 0;
                $news->description_vi=$request->description_vi;
                $news->description_en=$request->description_en;
                $news->post_type=$request->post_type;
                $news->slug= str_slug($request->title_vi);
                if($news->save()){
                    if($flag==1){

                        if(File::exists(public_path('images/news/'.$image_old))) {
                            File::delete(public_path('images/news/'.$image_old));
                        }
                    }
                    return redirect()->back()->with('success','Cập nhật tin tức thành công!');
                }else{
                    if($flag==1){
                        if(File::exists(public_path('images/news/'.$news->image))) {
                            File::delete(public_path('images/news/'.$news->image));
                        }
                    }
                    return redirect()->back()->with('error','Cập nhật Tin tức không thành công!');
                }
            }else{

                return redirect('admin/error');
            }

        }catch (\Exception $e){
            return redirect('admin/error');
        }
    }
}