<?php

/**
 * Created by PhpStorm.
 * User: ThangLe
 * Date: 7/5/2018
 * Time: 3:37 PM
 */
namespace App\Http\Controllers\Backend\Account;
use App\Http\Controllers\Controller;

class AccountController extends Controller
{
    public function getAll(){

    }
    public function findById($user_id){

    }
    public function delele(){

    }
}