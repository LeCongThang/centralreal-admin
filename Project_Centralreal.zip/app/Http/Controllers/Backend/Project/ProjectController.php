<?php

namespace App\Http\Controllers\Backend\Project;

use App\Http\Controllers\Controller;
use App\Models\Project;
use App\Models\ProjectImage;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Image;
use File;

class ProjectController extends Controller
{
    public function getAll()
    {
        try{
            $projects=Project::orderByDesc('updated_at')
                ->get();
            return view('backend.project.index',[
                'projects'=>$projects
            ]);
        }catch (\Exception $e){
            return redirect('admin/error');
        }
    }

    public function deleteProject($project_id){
        try{
            $project=Project::find($project_id);
            return view('backend.project.delete',[
                'project'=>$project
            ]);
        }catch (\Exception $e){
            return redirect('admin/error');
        }
    }
    public function destroyProject($project_id){
        try{
            $project=Project::find($project_id);
            $image=$project->image;
            if($project){
                $result=DB::transaction(function() use ($project,$project_id, $image){
                    $img=ProjectImage::where('project_id',$project_id)->get();
                    if(count($img)){
                        foreach ($img as $im){
                            if(File::exists(public_path('images/project/'.$im->image))) {
                                File::delete(public_path('images/project/'.$im->image));
                            }
                            $im->delete();
                        }
                    }
                    $project->delete();
                    if(File::exists(public_path('images/project/'.$image))) {
                        File::delete(public_path('images/project/'.$image));
                    }
                    return redirect()->back()->with('success','Xóa thành công!');
                });
                return $result;
            }else{
                return redirect()->back()->with('error','Không tồn tại!');
            }
        }catch (\Exception $e){
            return redirect()->back()->with('error','Xóa thất bại!');
        }
    }
}
