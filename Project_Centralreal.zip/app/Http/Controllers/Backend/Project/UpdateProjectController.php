<?php

namespace App\Http\Controllers\Backend\Project;

use App\Http\Controllers\Controller;
use App\Models\Project;
use App\Models\ProjectImage;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Image;
use File;

class UpdateProjectController extends Controller
{
    /**
     * UpdateProjectController constructor.
     */
    public function __construct()
    {
        $this->middleware('auth');
    }

    /**
     * @param $project_id
     * @return \Illuminate\Contracts\View\Factory|\Illuminate\View\View
     */
    public function Edit($project_id)
    {
        try{
            $project=Project::find($project_id);
            if($project){

                $image=ProjectImage::where('project_id',$project_id)
                    ->get();
                return view('backend.project.detail',[
                    'project'=>$project,
                    'image'=>$image
                ]);
            }else{
                return redirect()->back()->with(['error'=>'Không tồn tại!!']);
            }
        }catch (\Exception $e){
            return redirect('admin/error');
        }

    }

    /**
     * @param Request $request
     * @return \Illuminate\Contracts\View\Factory|\Illuminate\Http\RedirectResponse|\Illuminate\Routing\Redirector|\Illuminate\View\View
     */
    public function Update($id,Request $request)
    {
        $arr_image_insert=array();
        try{
            if (empty($request->get('title_vi')))
                return redirect()->back()->with('error','Vui lòng không để trống tiêu đề tiếng việt')->withInput();
            if (empty($request->get('title_en')))
                return redirect()->back()->with('error','Vui lòng không để trống tiêu đề tiếng anh')->withInput();
            if (empty($request->get('investor_vi')))
                return redirect()->back()->with('error','Vui lòng không để trống chủ đầu tư tiếng việt')->withInput();
            if (empty($request->get('investor_en')))
                return redirect()->back()->with('error','Vui lòng không để trống chủ đầu tư tiếng anh')->withInput();
            if (empty($request->get('location_vi')))
                return redirect()->back()->with('error','Vui lòng không để trống vị trí dự án tiếng việt')->withInput();
            if (empty($request->get('location_en')))
                return redirect()->back()->with('error','Vui lòng không để trống trí dự án tiếng anh')->withInput();
            if (empty($request->get('type_of_project_vi')))
                return redirect()->back()->with('error','Vui lòng không để trống loại dự án tiếng việt')->withInput();
            if (empty($request->get('type_of_project_en')))
                return redirect()->back()->with('error','Vui lòng không để trống loại dự án tiếng anh')->withInput();
            if (empty($request->get('description_vi')))
                return redirect()->back()->with('error','Vui lòng không để trống nội dung tiếng việt')->withInput();
            if (empty($request->get('description_en')))
                return redirect()->back()->with('error','Vui lòng không để trống nội dung tiếng anh')->withInput();
            if ($request->hasFile('image')){
                if (count($request->file('image'))>5)
                    return redirect()->back()->with('error','Số lượng hình tối đa là 5')->withInput();
            }
            $project=Project::find($id);
            if($project){
                $arr_image=array();
                $project->title_vi=$request->title_vi;
                $project->title_en=$request->title_en;
                $project->investor_vi=$request->investor_vi;
                $project->investor_en=$request->investor_en;
                $project->location_vi=$request->location_vi;
                $project->location_en=$request->location_en;
                $project->type_of_project_vi=$request->type_of_project_vi;
                $project->type_of_project_en=$request->type_of_project_en;
                $project->slug=str_slug($request->title_vi);
                $project->description_vi=$request->description_vi;
                $project->description_en=$request->description_en;
                if ($request->hasFile('avatar')) {
                    $image = $request->file('avatar');
                    $filename = 'project-' .time().'.'. $image->getClientOriginalExtension();
                    $destinationPath = public_path('images/project/'.$filename);
                    Image::make($image->getRealPath())->resize(800,600)->save($destinationPath);
                    $project->image = $filename;
                }
                $result=DB::transaction(function() use ($project, $request,$arr_image,$arr_image_insert){
                    if (!empty($request->get('arrImage'))){
                        $arr=explode(",",substr($request->arrImage, 0, -1));
                        foreach ($arr as $img){
                            $image1=ProjectImage::find($img);
                            if($image1){
                                array_push($arr_image,$image1->image);
                                $image1->delete();
                            }
                        }
                    }
                    $project->save();
                    if ($request->hasFile('image')) {
                        $image = $request->file('image');
                        $i=0;
                        foreach ($image as $file) {
                            $gallery_image=new ProjectImage();
                            $gallery_image->project_id=$project->id;
                            $file_name = 'project-' .time().$i. '.'.$file->getClientOriginalExtension();
                            $destinationPath = public_path('images/project/'.$file_name);
                            Image::make($file->getRealPath())->resize(1200, 800)->save($destinationPath);
                            $gallery_image->image = $file_name;
                            $gallery_image->save();
                            array_push($arr_image_insert,$file_name);
                            $i++;
                        }
                    }
                    if(count($arr_image)!=0){
                        foreach ($arr_image as $item){
                            if(File::exists(public_path('images/project/'.$item))) {
                                File::delete(public_path('images/project/'.$item));
                            }
                        }

                    }
                    return redirect('admin/project')->with('success','Cập nhật thành công!');
                });
                return $result;
            }else{
                if(count($arr_image_insert)!=0){
                    foreach ($arr_image_insert as $item){
                        if(File::exists(public_path('images/project/'.$item))) {
                            File::delete(public_path('images/project/'.$item));
                        }
                    }
                }
                return redirect('admin/error');
            }

        }catch (\Exception $e){
            return redirect('admin/error');
        }

    }
}
