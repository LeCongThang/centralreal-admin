<?php

/**
 * Created by PhpStorm.
 * User: ThangLe
 * Date: 7/10/2018
 * Time: 11:00 PM
 */

namespace App\Http\Controllers\Frontend;

use App\Http\Controllers\Controller;
use App\Models\Project;

class ProjectController extends Controller
{
    /**
     * Get all project
     *
     * @return $this
     */
    public function getAllProject()
    {
        $project_list = Project::with('project_images')->orderByDesc('updated_at')->paginate(9);
        if ($project_list) {
            return response()->json([
                'data' => $project_list,
                'message' => 'Success'
            ])->setStatusCode('200', 'Success');
        }
        return response()->json([
            'data' => [],
            'message' => 'Data null'
        ])->setStatusCode('400', 'Bad request');
    }

    /**
     * Get project by id
     *
     * @param $project_id
     * @return $this
     */
    public function getProjectById($project_id){
        $project = Project::with('project_images')->find($project_id);
        if($project){
            return response()->json([
                'data' => $project,
                'message' => 'Success'
            ])->setStatusCode('200', 'Success');
        }
        return response()->json([
            'data' => [],
            'message' => 'Data Not found'
        ])->setStatusCode('404', 'Not found');
    }
}