<?php
/**
 * Created by PhpStorm.
 * User: ThangLe
 * Date: 7/10/2018
 * Time: 11:22 PM
 */

namespace App\Http\Controllers\Frontend;


use App\Http\Controllers\Controller;
use App\Models\Recruitment;

class RecruitmentController extends Controller
{
    /**
     * Get all recruitment
     *
     * @return $this
     */
    public function getAllRecruitment()
    {
        $recruitment_list = Recruitment::orderByDesc('updated_at')->get();
        if ($recruitment_list) {
            return response()->json([
                'data' => $recruitment_list,
                'message' => 'Success'
            ])->setStatusCode('200', 'Success');
        }
        return response()->json([
            'data' => [],
            'message' => 'Data null'
        ])->setStatusCode('400', 'Bad request');
    }

    /**
     * Get recruitment by id
     *
     * @param $recruitment_id
     * @return $this
     */
    public function getRecruitmentById($recruitment_id)
    {
        $recruitment = Recruitment::find($recruitment_id);
        if ($recruitment) {
            return response()->json([
                'data' => $recruitment,
                'message' => 'Success'
            ])->setStatusCode('200', 'Success');
        }
        return response()->json([
            'data' => [],
            'message' => 'Data Not found'
        ])->setStatusCode('404', 'Not found');
    }
}