<?php
/**
 * Created by PhpStorm.
 * User: ThangLe
 * Date: 7/10/2018
 * Time: 11:29 PM
 */

namespace App\Http\Controllers\Frontend;


use App\Http\Controllers\Controller;
use App\Models\Gallery;

class GalleryController extends Controller
{
    /**
     * Get all gallery
     *
     * @return $this
     */
    public function getAllGallery()
    {
        $gallery_list = Gallery::with(['gallery_images'])->where('is_active',1)
            ->orderByDesc('updated_at')->paginate(9);
        if ($gallery_list) {
            return response()->json([
                'data' => $gallery_list,
                'message' => 'Success'
            ])->setStatusCode('200', 'Success');
        }
        return response()->json([
            'data' => [],
            'message' => 'Data null'
        ])->setStatusCode('400', 'Bad request');
    }

    /**
     * Get gallery by id
     *
     * @param $gallery_id
     * @return $this
     */
    public function getGalleryById($gallery_id)
    {
        $gallery = Gallery::with(['gallery_images'])->find($gallery_id);
        if ($gallery) {
            return response()->json([
                'data' => $gallery,
                'message' => 'Success'
            ])->setStatusCode('200', 'Success');
        }
        return response()->json([
            'data' => [],
            'message' => 'Data Not found'
        ])->setStatusCode('404', 'Not found');
    }
}