<?php

namespace App\Http\Controllers\Frontend;

use App\Models\ClientFeedback;
use App\Models\Gallery;
use App\Models\News;
use App\Models\Partner;
use App\Models\Project;
use App\Models\Slider;
use App\Models\SystemConfig;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;

class HomeController extends Controller
{
    //
   public function getHome(){
       try{
           $config=SystemConfig::first();
           $sliders=Slider::orderByDesc('updated_at')->get();
           $projects=Project::with('project_images')
               ->orderByDesc('updated_at')->limit(6)->get();
           $events=News::where('is_featured',1)->where('post_type',0)->orderByDesc('updated_at')->get();
           $galleries=Gallery::with('gallery_images')->where('is_active', 1)->orderByDesc('updated_at')->limit(6)->get();
           $news=News::where('is_featured',1)->where('post_type',1)->orderByDesc('updated_at')->get();
           $feed_backs=ClientFeedback::orderByDesc('updated_at')->get();
           $partners= Partner::orderByDesc('updated_at')->get();
           return response()->json([
               'data' => [
                   'config'=>$config,
                   'sliders'=>$sliders,
                   'projects'=>$projects,
                   'events'=>$events,
                   'galleries'=>$galleries,
                   'news'=>$news,
                   'feed_backs'=>$feed_backs,
                   'partners'=>$partners
               ],
               'message' => 'Success'
           ])->setStatusCode('200', 'Success');
       }catch (\Exception $e){
           return response()->json([
               'data' => [],
               'message' => 'Data null'
           ])->setStatusCode('400', 'Bad request');
       }
   }
}
