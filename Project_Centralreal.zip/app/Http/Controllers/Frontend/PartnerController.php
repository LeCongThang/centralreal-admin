<?php
/**
 * Created by PhpStorm.
 * User: ThangLe
 * Date: 7/10/2018
 * Time: 11:33 PM
 */

namespace App\Http\Controllers\Frontend;


use App\Http\Controllers\Controller;
use App\Models\Partner;

class PartnerController extends Controller
{
    /**
     * Get all partner API
     *
     * @return $this
     */
    public function getAllPartner()
    {
        $partner_list = Partner::orderByDesc('updated_at')->get();
        if ($partner_list) {
            return response()->json([
                'data' => $partner_list,
                'message' => 'Success'
            ])->setStatusCode('200', 'Success');
        }
        return response()->json([
            'data' => [],
            'message' => 'Data null'
        ])->setStatusCode('400', 'Bad request');
    }
}