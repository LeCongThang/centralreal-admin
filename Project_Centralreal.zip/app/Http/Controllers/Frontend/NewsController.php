<?php
/**
 * Created by PhpStorm.
 * User: ThangLe
 * Date: 7/10/2018
 * Time: 11:18 PM
 */

namespace App\Http\Controllers\Frontend;


use App\Http\Controllers\Controller;
use App\Models\News;

class NewsController extends Controller
{

    /**
     * Get all news
     *
     * @return $this
     */
    public function getAllNews()
    {
        $news_list = News::orderByDesc('created_at')->paginate(9);
        if ($news_list) {
            return response()->json([
                'data' => $news_list,
                'message' => 'Success'
            ])->setStatusCode('200', 'Success');
        }
        return response()->json([
            'data' => [],
            'message' => 'Data null'
        ])->setStatusCode('400', 'Bad request');
    }

    /**
     * Get news by id
     *
     * @param $news_id
     * @return $this
     */
    public function getNewsById($news_id)
    {
        $news = News::find($news_id);
        if ($news) {
            return response()->json([
                'data' => $news,
                'message' => 'Success'
            ])->setStatusCode('200', 'Success');
        }
        return response()->json([
            'data' => [],
            'message' => 'Data Not found'
        ])->setStatusCode('404', 'Not found');
    }
}